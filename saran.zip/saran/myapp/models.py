from django.contrib.auth.models import AbstractUser, Group, Permission
from django.db import models

class Right(models.Model):  
    """ Model to define various permissions (rights) """
    name = models.CharField(max_length=100, unique=True)

    def __str__(self):
        return self.name

class Role(models.Model):  
    """ Model to define different roles (Super Admin, Admin, etc.) """
    name = models.CharField(max_length=100, unique=True)
    rights = models.ManyToManyField(Right, blank=True, related_name="roles") 

    def __str__(self):
        return self.name

class Member(AbstractUser):  
    """ Custom User model extending AbstractUser """
    role = models.ForeignKey(Role, on_delete=models.SET_NULL, null=True, related_name="members")

    groups = models.ManyToManyField(Group, related_name="custom_user_groups", blank=True)
    user_permissions = models.ManyToManyField(Permission, related_name="custom_user_permissions", blank=True)

    def __str__(self):
        return self.username
