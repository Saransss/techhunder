from django.core.management.base import BaseCommand
from myapp.models import Right

class Command(BaseCommand):
    help = "Populate initial Rights"

    def handle(self, *args, **kwargs):
        rights_list = [
            "Create User", "Edit User", "Delete User",
            "Create Role", "Edit Role", "Delete Role",
            "Create Right", "Edit Right", "Delete Right"
        ]

        for right_name in rights_list:
            right, created = Right.objects.get_or_create(name=right_name)
            if created:
                self.stdout.write(self.style.SUCCESS(f"✅ Created Right: {right_name}"))
            else:
                self.stdout.write(self.style.WARNING(f"⚠️ Right already exists: {right_name}"))

        self.stdout.write(self.style.SUCCESS("✅ Rights population completed."))
