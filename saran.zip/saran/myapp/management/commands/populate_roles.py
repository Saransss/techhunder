from django.core.management.base import BaseCommand
from myapp.models import Role, Right

class Command(BaseCommand):
    help = "Populate initial Roles with Rights"

    def handle(self, *args, **kwargs):
        rights_dict = {right.name: right for right in Right.objects.all()}

        roles_data = {
            "Super Admin": list(rights_dict.values()),  # Assign all rights
            "Admin": [r for r in rights_dict.values() if r.name != "Delete User"],  
            "Operators": [rights_dict.get("Create User"), rights_dict.get("Edit User")],
            "Technicians": []
        }

        for role_name, rights in roles_data.items():
            role, created = Role.objects.get_or_create(name=role_name)
            if rights:
                role.rights.set(rights)  # Assign rights
            role.save()

            if created:
                self.stdout.write(self.style.SUCCESS(f"✅ Created Role: {role_name}"))
            else:
                self.stdout.write(self.style.WARNING(f"⚠️ Role already exists: {role_name}"))

        self.stdout.write(self.style.SUCCESS("✅ Roles populated successfully."))
