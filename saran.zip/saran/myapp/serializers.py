from rest_framework import serializers
from .models import Member, Role, Right

class RightSerializer(serializers.ModelSerializer):
    class Meta:
        model = Right
        fields = '__all__'

class RoleSerializer(serializers.ModelSerializer):
    rights = RightSerializer(many=True, read_only=True)
    rights_ids = serializers.PrimaryKeyRelatedField(
        queryset=Right.objects.all(),
        many=True,
        required=False,
        write_only=True,
        source="rights"
    )

    class Meta:
        model = Role
        fields = ['id', 'name', 'rights', 'rights_ids']

    def create(self, validated_data):
        rights = validated_data.pop('rights', [])
        role = Role.objects.create(**validated_data)
        role.rights.set(rights)
        return role

    def update(self, instance, validated_data):
        rights = validated_data.pop('rights', None)
        instance.name = validated_data.get('name', instance.name)

        if rights is not None:
            instance.rights.set(rights)

        instance.save()
        return instance

class MemberSerializer(serializers.ModelSerializer):
    role = RoleSerializer(read_only=True)
    role_id = serializers.PrimaryKeyRelatedField(
        queryset=Role.objects.all(), write_only=True, source="role"
    )

    class Meta:
        model = Member
        fields = ['id', 'username', 'role', 'role_id']

    def create(self, validated_data):
        role = validated_data.pop('role', None)
        member = Member.objects.create(**validated_data)
        if role:
            member.role = role
            member.save()
        return member

    def update(self, instance, validated_data):
        role = validated_data.pop('role', None)
        instance.username = validated_data.get('username', instance.username)

        if role is not None:
            instance.role = role

        instance.save()
        return instance
