from rest_framework import viewsets, permissions, serializers
from rest_framework.response import Response
from rest_framework import status
from django.contrib.auth import get_user_model
from .models import Member, Role, Right
from .serializers import MemberSerializer, RoleSerializer, RightSerializer

User = get_user_model()

class RightViewSet(viewsets.ModelViewSet):
    queryset = Right.objects.all()
    serializer_class = RightSerializer
    permission_classes = [permissions.IsAuthenticated]


class RoleViewSet(viewsets.ModelViewSet):
    queryset = Role.objects.all()
    serializer_class = RoleSerializer
    permission_classes = [permissions.IsAuthenticated]

class MemberViewSet(viewsets.ModelViewSet):
    queryset = User.objects.all() 
    serializer_class = MemberSerializer
    permission_classes = [permissions.IsAuthenticated]

    def perform_create(self, serializer):
        """ Restrict users from assigning their own role """
        user_role = getattr(self.request.user, "role", None) 
        new_role = serializer.validated_data.get("role")  

        if user_role and new_role:
            if user_role.name == "Admin" and new_role.name == "Super Admin":
                raise serializers.ValidationError("Admins cannot assign Super Admin roles.")
            if user_role == new_role:
                raise serializers.ValidationError("You cannot assign your own role.")
        
        serializer.save()

    def destroy(self, request, *args, **kwargs):
        """ Prevent users from deleting members with the same role """
        instance = self.get_object()
        
        if instance.role and request.user.role:
            if request.user.role.name == instance.role.name:
                return Response(
                    {"error": f"You cannot delete users with the {instance.role.name} role."},
                    status=status.HTTP_403_FORBIDDEN
                )
            if instance.role.name == "Super Admin":
                return Response(
                    {"error": "Super Admins cannot be deleted."},
                    status=status.HTTP_403_FORBIDDEN
                )

        self.perform_destroy(instance)
        return Response(status=status.HTTP_204_NO_CONTENT)
