from django.contrib import admin
from .models import Role  # Importing the Role model from models.py

@admin.register(Role)
class RoleAdmin(admin.ModelAdmin):
    list_display = ('id', 'name')  # Adjust fields as per your model
